import pandas as pd
import matplotlib.pyplot as plt
 
df = pd.read_csv("tourism_records.csv")
 
df["Visit_Date"] = pd.to_datetime(df["Visit_Date"])
df["Month"] = df["Visit_Date"].dt.month
 
visits = df["Destination"].value_counts()
monthly = df["Month"].value_counts().sort_index()
modes = df["Travel_Mode"].value_counts()
 
print("Visits by Destination")
print(visits)
 
print("Monthly Visits")
print(monthly)
 
print("Average Stay and Expense")
print(df.groupby("Tourist_Type")[["Stay_Days", "Total_Expense"]].mean())
 
print("Average Accommodation Cost")
print(df.groupby("Destination")["Accommodation_Cost"].mean())
 
print("Travel Modes")
print(modes)
 
plt.bar(visits.index, visits.values, label='visits')
plt.legend(loc='upper right')
plt.xlabel('Destination')
plt.ylabel('Visits')
plt.title('Tourist Visits by Destination')
plt.xticks(rotation=45)
plt.show()
 
plt.plot(monthly.index, monthly.values, label='visits')
plt.legend(loc='upper right')
plt.xlabel('Month')
plt.ylabel('Visits')
plt.title('Monthly Tourist Visits')
plt.show()
 
plt.pie(modes.values, labels=modes.index, autopct="%1.1f%%")
plt.title('Travel Mode Distribution')
plt.show()
 
plt.hist(df["Stay_Days"], bins=10, label="tourists")
plt.legend(loc='upper right')
plt.xlabel('Stay Days')
plt.ylabel('Tourists')
plt.title('Stay Duration Distribution')
plt.show()
 
types = df["Tourist_Type"].unique()
data1 = df[df["Tourist_Type"] == types[0]]["Total_Expense"]
data2 = df[df["Tourist_Type"] == types[1]]["Total_Expense"]
 
plt.boxplot([data1, data2], tick_labels=types)
plt.xlabel('Tourist Type')
plt.ylabel('Total Expense')
plt.title('Total Expenses by Tourist Type')
plt.show()

